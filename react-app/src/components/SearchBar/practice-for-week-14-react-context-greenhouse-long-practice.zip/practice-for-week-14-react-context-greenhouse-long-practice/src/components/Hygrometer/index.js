import Hygrometer from "./Hygrometer";

export default Hygrometer;
