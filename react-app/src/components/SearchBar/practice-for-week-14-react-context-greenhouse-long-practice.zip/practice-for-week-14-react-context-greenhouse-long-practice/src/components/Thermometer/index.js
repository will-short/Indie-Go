import Thermometer from './Thermometer';

export default Thermometer;